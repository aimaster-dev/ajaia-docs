Brand assets for the Ajaia Docs demo.
